import os
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

st.set_page_config(page_title="CyberShield Risk Dashboard", page_icon="🛡️", layout="wide")
st.title("🛡️ CyberShield – Student Cyber Risk Dashboard")
st.caption("Competition prototype using a 100-record synthetic dataset. This is not real student survey data.")

DATA_PATH = "CyberSafe_Student_Dataset.csv"
if not os.path.exists(DATA_PATH):
    st.error("Dataset CSV tidak dijumpai. Letakkan CyberSafe_Student_Dataset.csv dalam folder yang sama dengan fail dashboard.")
    st.stop()

df = pd.read_csv(DATA_PATH)
risk_order = ["Low", "Medium", "High"]
risk_counts = df["Risk_Level"].value_counts().reindex(risk_order, fill_value=0)

c1, c2, c3, c4 = st.columns(4)
c1.metric("Jumlah rekod", len(df))
c2.metric("Low Risk", int(risk_counts["Low"]))
c3.metric("Medium Risk", int(risk_counts["Medium"]))
c4.metric("High Risk", int(risk_counts["High"]))

st.subheader("1. Taburan tahap risiko")
fig, ax = plt.subplots()
risk_counts.plot(kind="bar", ax=ax)
ax.set_xlabel("Risk Level")
ax.set_ylabel("Number of Students")
ax.set_title("Students by Risk Level")
ax.tick_params(axis="x", rotation=0)
st.pyplot(fig)

left, right = st.columns(2)
with left:
    st.subheader("2. Password Strength vs Risk")
    tab = pd.crosstab(df["Password_Strength"], df["Risk_Level"]).reindex(
        index=["Weak", "Medium", "Strong"], columns=risk_order, fill_value=0)
    st.dataframe(tab)
    fig, ax = plt.subplots()
    tab.plot(kind="bar", ax=ax)
    ax.set_xlabel("Password Strength")
    ax.set_ylabel("Number of Students")
    ax.tick_params(axis="x", rotation=0)
    st.pyplot(fig)

with right:
    st.subheader("3. MFA Enabled vs Risk")
    tab = pd.crosstab(df["MFA_Enabled"], df["Risk_Level"]).reindex(
        index=["Yes", "No"], columns=risk_order, fill_value=0)
    st.dataframe(tab)
    fig, ax = plt.subplots()
    tab.plot(kind="bar", ax=ax)
    ax.set_xlabel("MFA Enabled")
    ax.set_ylabel("Number of Students")
    ax.tick_params(axis="x", rotation=0)
    st.pyplot(fig)

st.subheader("4. Security Training vs Risk")
training_tab = pd.crosstab(df["Security_Training"], df["Risk_Level"]).reindex(
    index=["Yes", "No"], columns=risk_order, fill_value=0)
st.dataframe(training_tab)

st.subheader("5. Dataset")
st.dataframe(df, use_container_width=True)

st.info("Nota metodologi: Risk_Level dijana menggunakan sistem pemarkahan dalam tugasan. Model AI yang dilatih pada label ini menunjukkan pembelajaran peraturan simulasi, bukan bukti ramalan risiko sebenar.")
