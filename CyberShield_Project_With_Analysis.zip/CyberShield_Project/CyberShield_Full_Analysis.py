"""
CyberShield / CyberSafe School Analytics Challenge 2026
End-to-end project script:
1) Generate 100 synthetic records
2) Clean and inspect data
3) Perform required analysis
4) Create Matplotlib visualisations
5) Train and evaluate a Decision Tree classifier
6) Save outputs for the dashboard and report

IMPORTANT:
- This dataset is synthetic (randomly generated), NOT real student survey data.
- Risk_Level is assigned using the scoring rule in the competition brief.
- Therefore, the classifier demonstrates learning that rule; it is not a validated
  predictor of real-world student behaviour.
"""

import random
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, ConfusionMatrixDisplay

OUTPUT_DIR = "cybershield_outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 1. Generate the required synthetic dataset (100 records)
random.seed(42)
records = []

for i in range(1, 101):
    password = random.choice(["Weak", "Medium", "Strong"])
    unknown_link = random.choice(["Yes", "No"])
    mfa = random.choice(["Yes", "No"])
    training = random.choice(["Yes", "No"])
    wifi = random.choice(["Yes", "No"])
    sharing = random.choice(["Yes", "No"])

    score = 0
    if password == "Weak":
        score += 3
    elif password == "Medium":
        score += 1
    if unknown_link == "Yes":
        score += 3
    if mfa == "No":
        score += 2
    if training == "No":
        score += 2
    if wifi == "Yes":
        score += 1
    if sharing == "Yes":
        score += 2

    if score >= 9:
        risk = "High"
    elif score >= 5:
        risk = "Medium"
    else:
        risk = "Low"

    records.append({
        "Student_ID": f"S{i:03d}",
        "Password_Strength": password,
        "Unknown_Link_Clicked": unknown_link,
        "MFA_Enabled": mfa,
        "Security_Training": training,
        "Public_Wifi_Usage": wifi,
        "Account_Sharing": sharing,
        "Risk_Level": risk
    })

df = pd.DataFrame(records)
csv_file = os.path.join(OUTPUT_DIR, "CyberSafe_Student_Dataset.csv")
df.to_csv(csv_file, index=False)

# 2. Import, clean and inspect
df = pd.read_csv(csv_file)
df = df.drop_duplicates()
df = df.dropna()
df["Student_ID"] = df["Student_ID"].astype(str).str.strip()

print("\\nFIRST 10 RECORDS")
print(df.head(10))
print("\\nDATASET INFORMATION")
df.info()
print("\\nMISSING VALUES")
print(df.isnull().sum())

# 3. Required analysis
print("\\n1. NUMBER OF STUDENTS BY RISK LEVEL")
risk_counts = df["Risk_Level"].value_counts().reindex(["Low", "Medium", "High"], fill_value=0)
print(risk_counts)

print("\\n2. PASSWORD STRENGTH VS RISK LEVEL")
password_risk = pd.crosstab(df["Password_Strength"], df["Risk_Level"])
print(password_risk)

print("\\n3. MFA ENABLED VS RISK LEVEL")
mfa_risk = pd.crosstab(df["MFA_Enabled"], df["Risk_Level"])
print(mfa_risk)

print("\\n4. SECURITY TRAINING VS RISK LEVEL")
training_risk = pd.crosstab(df["Security_Training"], df["Risk_Level"])
print(training_risk)

# Additional descriptive summaries
factor_summary = pd.DataFrame({
    "Risk_Factor": [
        "Weak password",
        "Clicked unknown link",
        "MFA not enabled",
        "No security training",
        "Public Wi-Fi usage",
        "Account sharing"
    ],
    "Students_With_Behaviour": [
        (df["Password_Strength"] == "Weak").sum(),
        (df["Unknown_Link_Clicked"] == "Yes").sum(),
        (df["MFA_Enabled"] == "No").sum(),
        (df["Security_Training"] == "No").sum(),
        (df["Public_Wifi_Usage"] == "Yes").sum(),
        (df["Account_Sharing"] == "Yes").sum()
    ]
}).sort_values("Students_With_Behaviour", ascending=False)

print("\\nRISK BEHAVIOUR COUNTS")
print(factor_summary)

# Save analysis tables
risk_counts.rename_axis("Risk_Level").reset_index(name="Student_Count").to_csv(
    os.path.join(OUTPUT_DIR, "risk_distribution.csv"), index=False)
password_risk.to_csv(os.path.join(OUTPUT_DIR, "password_vs_risk.csv"))
mfa_risk.to_csv(os.path.join(OUTPUT_DIR, "mfa_vs_risk.csv"))
training_risk.to_csv(os.path.join(OUTPUT_DIR, "training_vs_risk.csv"))
factor_summary.to_csv(os.path.join(OUTPUT_DIR, "risk_factor_summary.csv"), index=False)

# 4. Required Matplotlib graphs (at least 3)
plt.figure(figsize=(7, 5))
risk_counts.plot(kind="bar")
plt.title("Number of Students by Cyber Risk Level")
plt.xlabel("Risk Level")
plt.ylabel("Number of Students")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "graph_1_risk_distribution.png"), dpi=160)
plt.close()

password_risk.reindex(["Weak", "Medium", "Strong"]).reindex(
    columns=["Low", "Medium", "High"], fill_value=0
).plot(kind="bar", figsize=(8, 5))
plt.title("Password Strength vs Risk Level")
plt.xlabel("Password Strength")
plt.ylabel("Number of Students")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "graph_2_password_vs_risk.png"), dpi=160)
plt.close()

mfa_risk.reindex(["Yes", "No"]).reindex(columns=["Low", "Medium", "High"], fill_value=0).plot(
    kind="bar", figsize=(8, 5)
)
plt.title("MFA Enabled vs Risk Level")
plt.xlabel("MFA Enabled")
plt.ylabel("Number of Students")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "graph_3_mfa_vs_risk.png"), dpi=160)
plt.close()

# Extra graph for security training
training_risk.reindex(["Yes", "No"]).reindex(
    columns=["Low", "Medium", "High"], fill_value=0
).plot(kind="bar", figsize=(8, 5))
plt.title("Security Training vs Risk Level")
plt.xlabel("Security Training")
plt.ylabel("Number of Students")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "graph_4_training_vs_risk.png"), dpi=160)
plt.close()

# 5. AI classification model
features = [
    "Password_Strength",
    "Unknown_Link_Clicked",
    "MFA_Enabled",
    "Security_Training",
    "Public_Wifi_Usage",
    "Account_Sharing"
]
X = pd.get_dummies(df[features])
y = df["Risk_Level"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = DecisionTreeClassifier(max_depth=5, random_state=42)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)
labels = ["Low", "Medium", "High"]
cm = confusion_matrix(y_test, predictions, labels=labels)

print("\\nMODEL ACCURACY:", round(accuracy * 100, 2), "%")
print("\\nCONFUSION MATRIX (rows=actual, columns=predicted)")
print(pd.DataFrame(cm, index=labels, columns=labels))
print("\\nCLASSIFICATION REPORT")
print(classification_report(y_test, predictions, zero_division=0))

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
disp.plot()
plt.title("Confusion Matrix - Decision Tree")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "confusion_matrix.png"), dpi=160)
plt.close()

with open(os.path.join(OUTPUT_DIR, "model_metrics.txt"), "w", encoding="utf-8") as f:
    f.write(f"Accuracy: {accuracy:.4f}\\n")
    f.write("Labels order: Low, Medium, High\\n")
    f.write(str(pd.DataFrame(cm, index=labels, columns=labels)))

print("\\nALL OUTPUTS SAVED IN:", OUTPUT_DIR)
print("\\nNOTE: This is a demonstration model trained on synthetic data and rule-generated labels.")
