# CyberShield Project Starter Pack

## Kandungan
- `CyberSafe_Student_Dataset.csv`: 100 rekod simulasi, 8 medan.
- `CyberShield_Full_Analysis.py`: menjana semula dataset, membersihkan data, membuat 4 analisis, 4 graf, model Decision Tree, accuracy dan confusion matrix.
- `CyberShield_Dashboard.py`: dashboard Streamlit asas yang membaca fail CSV.
- `requirements.txt`: pustaka Python yang diperlukan.

## Cara menjalankan analisis
1. Buka Google Colab atau Python.
2. Muat naik `CyberShield_Full_Analysis.py`.
3. Jalankan skrip selepas memasang pustaka dalam `requirements.txt`.
4. Semua hasil akan disimpan dalam folder `cybershield_outputs`.

## Cara menjalankan dashboard
1. Pasang keperluan: `pip install -r requirements.txt`
2. Letakkan `CyberSafe_Student_Dataset.csv` dan `CyberShield_Dashboard.py` dalam folder yang sama.
3. Jalankan: `streamlit run CyberShield_Dashboard.py`

## Penting untuk pertandingan
Dataset ini ialah data simulasi yang dijana secara rawak menggunakan Python, bukan 100 jawapan Google Forms. Risk_Level ditetapkan melalui sistem pemarkahan yang diberikan dalam arahan pertandingan. Oleh itu, model AI ialah demonstrasi pembelajaran peraturan pada data sintetik dan tidak boleh didakwa sebagai model ramalan yang telah disahkan menggunakan data sebenar.
